# Maya – Jarvis-style Hindi voice assistant (Android, Kotlin)
## APK बनाने के चरण
1. Android Studio (Koala या नया) में File > Open > MayaJarvis फ़ोल्डर। Gradle sync अपने-आप wrapper बना लेगा।
2. फ़ोन (Realme RMX5120): Settings > About > Build number 7 बार दबाकर Developer options > USB debugging चालू करें, USB से जोड़ें।
3. Run ▶ दबाएँ, या Build > Build APK(s) से APK बनाएँ।
4. ऐप में: API key सेव → अनुमतियाँ → Accessibility ON → Notification Access ON → "Maya शुरू करें"।
   (Realme/ColorOS में Settings > Battery में ऐप को "Don't restrict" और Autostart ON करें, वरना बैकग्राउंड में बंद हो सकता है।)
5. बोलें: "माया, यूट्यूब खोलो", "माया, नीचे स्क्रॉल करो", "माया, एक पोर्टफ़ोलियो वेबसाइट बनाओ"।
## ढाँचा
MainActivity(सेटअप) · MayaService(सुनना/बोलना) · Brain(Gemini+Function Calling लूप) · Tools(टूल रजिस्ट्री+सुरक्षा ब्लॉकलिस्ट) · MayaAccessibilityService(स्क्रीन कंट्रोल) · MayaNotificationListener(सूचनाएँ)
## सुरक्षा
बैंकिंग/UPI ऐप ब्लॉक हैं; संवेदनशील काम से पहले Maya पूछती है; Kill switch = ■ रोकें बटन।
