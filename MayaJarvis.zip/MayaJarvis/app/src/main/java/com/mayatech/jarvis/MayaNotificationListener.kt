package com.mayatech.jarvis

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** हर नई नोटिफ़िकेशन की जानकारी Maya बोलकर देती है */
class MayaNotificationListener : NotificationListenerService() {
    private var last = 0L
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val now = System.currentTimeMillis(); if (now - last < 4000) return; last = now
        val e = sbn.notification.extras
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)) } catch (x: Exception) { sbn.packageName }
        val msg = "$app से नई सूचना: ${e.getCharSequence("android.title") ?: ""}. ${e.getCharSequence("android.text") ?: ""}"
        MayaService.announce(msg.take(160))
    }
}
