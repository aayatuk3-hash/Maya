package com.mayatech.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini + Function Calling एजेंट लूप */
class Brain(private val key: () -> String) {
    @Volatile var lastError = ""
    private val history = JSONArray()
    private val system = """तुम "Maya" हो: यूज़र की निजी हिंदी AI सहायक, Jarvis जैसी।
स्वभाव: गर्मजोशी भरी, दोस्ताना, बेहद जानकार, सीधी और ईमानदार। यूज़र के साथ सम्मान से, बराबरी से बात करो, उसे समझदार वयस्क मानो।
- पहले सीधा जवाब दो, फिर ज़रूरत हो तो थोड़ा विस्तार। भूमिका या दोहराव नहीं।
- जो न पता हो उसे साफ़ मान लो, अंदाज़े को पक्का तथ्य मत बताओ। गलती हो तो सीधे मान लो और सुधारो।
- ज़रूरत पड़ने पर विनम्रता से असहमति जताओ, पर चापलूसी मत करो।
- जवाब बोलने लायक हों: छोटे वाक्य, सरल हिंदी, कोई markdown या सूची नहीं। एक बार में एक ही सवाल पूछो।
- यूज़र परेशान हो तो पहले संवेदना दिखाओ, फिर मदद करो।
फ़ोन चलाने के लिए टूल्स इस्तेमाल करो: पहले read_screen से देखो, फिर tap_text/scroll/type_text करो, हर कदम के बाद दोबारा जाँचो।
कॉल और SMS से पहले यूज़र से साफ़ पूछो (किसे, और SMS में क्या लिखा है) और 'हाँ' मिलने पर ही confirmed=yes के साथ टूल चलाओ। पैसे भेजना, पासवर्ड, डिलीट जैसे काम से पहले भी पूछो।
ताज़ा खबर, भाव, मौसम के लिए web_search इस्तेमाल करो।
यूज़र की बात बोलकर आती है और पहचान में गलत शब्द आ सकते हैं (हिंदी-अंग्रेज़ी मिले हुए भी)। शब्द-दर-शब्द नहीं, संदर्भ और मतलब से समझो। बहुत उलझा हो तो एक छोटा सवाल पूछकर पक्का करो।
तुम स्क्रीन पर वही कर सकती हो जो टूल्स देते हैं; जो नहीं कर सकती, वह ईमानदारी से बताओ."""

    private fun decl(n: String, d: String, props: Map<String, String> = emptyMap()) = JSONObject().put("name", n).put("description", d).apply {
        if (props.isNotEmpty()) put("parameters", JSONObject().put("type", "OBJECT")
            .put("properties", JSONObject().also { o -> props.forEach { (k, v) -> o.put(k, JSONObject().put("type", "STRING").put("description", v)) } })
            .put("required", JSONArray(props.keys.toList())))
    }

    private val tools = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray()
        .put(decl("open_app", "ऐप का नाम बोलकर खोलो", mapOf("name" to "ऐप का नाम")))
        .put(decl("open_url", "वेबसाइट लिंक खोलो", mapOf("url" to "पूरा URL")))
        .put(decl("read_screen", "अभी स्क्रीन पर दिख रहा टेक्स्ट पढ़ो"))
        .put(decl("tap_text", "स्क्रीन पर इस टेक्स्ट वाले बटन/आइटम पर टैप करो", mapOf("text" to "टेक्स्ट")))
        .put(decl("scroll", "स्क्रीन स्क्रॉल करो", mapOf("direction" to "down या up")))
        .put(decl("type_text", "चुने हुए इनपुट बॉक्स में लिखो", mapOf("text" to "लिखने का टेक्स्ट")))
        .put(decl("go_back", "पीछे जाओ")).put(decl("go_home", "होम स्क्रीन पर जाओ"))
        .put(decl("call_phone", "किसी को कॉल करो (नाम या नंबर)", mapOf("target" to "संपर्क का नाम या फ़ोन नंबर", "confirmed" to "yes सिर्फ़ तब, जब यूज़र ने साफ़ 'हाँ' कहा हो; वरना no")))
        .put(decl("send_sms", "SMS भेजो", mapOf("target" to "संपर्क का नाम या फ़ोन नंबर", "message" to "संदेश का टेक्स्ट", "confirmed" to "yes सिर्फ़ तब, जब यूज़र ने संदेश सुनकर साफ़ 'हाँ' कहा हो; वरना no")))
        .put(decl("torch", "टॉर्च चालू या बंद करो", mapOf("state" to "on या off")))
        .put(decl("open_camera", "कैमरा ऐप खोलो"))
        .put(decl("set_alarm", "अलार्म लगाओ", mapOf("hour" to "घंटा 0-23", "minute" to "मिनट 0-59", "label" to "नाम")))
        .put(decl("set_timer", "टाइमर लगाओ", mapOf("seconds" to "कुल सेकंड", "label" to "नाम")))
        .put(decl("web_search", "इंटरनेट पर खोजकर ताज़ा खबर, भाव, मौसम आदि बताओ", mapOf("query" to "खोज का सवाल")))
        .put(decl("create_website", "पूरी HTML वेबसाइट फ़ाइल बनाकर सेव करो", mapOf("filename" to "नाम, जैसे site.html", "html" to "पूरा HTML कोड")))
    ))

    fun ask(userText: String): String {
        lastError = ""
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))
        repeat(10) {
            val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", history).put("tools", tools)
            val res = post(body)
            val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return fail(res)
            history.put(content)
            val parts = content.optJSONArray("parts") ?: return "ठीक है।"
            val responses = JSONArray(); var text = ""
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                p.optString("text").takeIf { it.isNotEmpty() }?.let { text += it }
                p.optJSONObject("functionCall")?.let { fc ->
                    val out = Tools.run(fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
                    responses.put(JSONObject().put("functionResponse", JSONObject().put("name", fc.getString("name"))
                        .put("response", JSONObject().put("result", out))))
                }
            }
            if (responses.length() == 0) return text.ifEmpty { "ठीक है।" }
            history.put(JSONObject().put("role", "user").put("parts", responses))
        }
        return "काम थोड़ा लंबा है, मैं यहीं रुक रही हूँ।"
    }

    private fun fail(res: JSONObject): String {
        val err = res.optJSONObject("error")
        if (err == null) { lastError = "खाली जवाब"; return "माफ़ कीजिए, इस बार जवाब नहीं बन पाया। एक बार फिर पूछिए।" }
        val code = err.optInt("code")
        lastError = "$code: " + err.optString("message").take(200)
        return when (code) {
            503 -> "अभी Google का सर्वर बहुत व्यस्त है। थोड़ी देर में फिर बोलिए, मैं यहीं हूँ।"
            429 -> "आज की मुफ़्त सीमा शायद पूरी हो गई है। थोड़ी देर बाद फिर बात करते हैं।"
            400, 401, 403 -> "मुझे लगता है API key सही नहीं है। ऐप खोलकर key फिर से डाल दीजिए।"
            else -> "थोड़ी दिक्कत आ गई है, कुछ देर बाद फिर कोशिश करते हैं।"
        }
    }

    private fun post(body: JSONObject): JSONObject = Models.call(key(), body)
}
