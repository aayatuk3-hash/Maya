package com.mayatech.jarvis

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.Executors

/** हमेशा सुनने वाली Foreground Service: कान (STT) + मुँह (TTS) + दिमाग (Brain) */
class MayaService : Service() {
    companion object {
        var ctx: Context? = null
        private var self: MayaService? = null
        fun announce(t: String) { self?.main?.post { self?.speak(t) } }
    }
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private var ttsReady = false
    private var busy = false
    private val brain by lazy { Brain { getSharedPreferences("maya", MODE_PRIVATE).getString("key", "") ?: "" } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate(); ctx = this; self = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("maya", "Maya", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "maya").setContentTitle("Maya सुन रही है")
            .setContentText("बोलिए: 'माया, ...'").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts.language = Locale("hi", "IN"); tts.setPitch(1.12f)
                val saved = getSharedPreferences("maya", MODE_PRIVATE).getString("voice", null)
                tts.voices?.firstOrNull { it.name == saved }?.let { tts.voice = it }
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) { main.post { listen() } }
                    override fun onDone(id: String?) { main.post { listen() } }
                })
                ttsReady = true; speak("नमस्ते! मैं माया हूँ। बताइए, मैं क्या करूँ?")
            }
        }
    }

    private val speaker = Executors.newSingleThreadExecutor()
    private fun speak(t: String) {
        rec?.cancel()
        val sp = getSharedPreferences("maya", MODE_PRIVATE)
        val key = sp.getString("key", "") ?: ""
        val voice = sp.getString("gvoice", "Kore") ?: "Kore"
        speaker.execute {
            val pcm = if (key.isNotEmpty()) GeminiVoice.synth(key, voice, t) else null
            if (pcm != null) { try { GeminiVoice.play(pcm) } catch (e: Exception) {}; main.post { listen() } }
            else main.post { if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_ADD, null, "m${System.nanoTime()}") else listen() }
        }
    }

    private fun listen() {
        if (busy || tts.isSpeaking) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (t.contains("माया") || t.contains("maya", true)) handle(t) else main.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) { main.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(a: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }

    private fun handle(text: String) {
        busy = true
        worker.execute {
            val ans = try { brain.ask(text) } catch (e: Exception) { "इंटरनेट या API key की दिक्कत है।" }
            main.post { busy = false; speak(ans) }
        }
    }

    override fun onDestroy() { rec?.destroy(); tts.shutdown(); worker.shutdown(); self = null; ctx = null; super.onDestroy() }
}
