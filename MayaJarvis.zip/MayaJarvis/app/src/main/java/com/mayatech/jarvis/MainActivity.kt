package com.mayatech.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("maya", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        col.addView(TextView(this).apply { text = "Maya – आपकी Jarvis सहायक"; textSize = 22f; gravity = Gravity.START })
        val key = EditText(this).apply {
            hint = "Gemini API key (aistudio.google.com/apikey)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(sp.getString("key", ""))
        }
        col.addView(key)
        btn("1. API key सेव करें") { sp.edit().putString("key", key.text.toString().trim()).apply(); toast("सेव हुआ") }
        btn("2. माइक/नोटिफ़िकेशन अनुमति") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("3. Accessibility चालू करें (स्क्रीन कंट्रोल)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("4. Notification Access चालू करें") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        var vi = 0
        btn("🔊 आवाज़ बदलें (हर दबाव पर नई महिला आवाज़)") {
            val key = sp.getString("key", "") ?: ""
            if (key.isEmpty()) toast("पहले API key सेव करें")
            else {
                val v = GeminiVoice.FEMALE[vi % GeminiVoice.FEMALE.size]; vi++
                sp.edit().putString("gvoice", v).apply()
                toast("आवाज़: $v (सुनिए...)")
                Thread {
                    val pcm = GeminiVoice.synth(key, v, "नमस्ते, मैं माया हूँ। क्या यह आवाज़ आपको पसंद आई?")
                    if (pcm == null) runOnUiThread { showErr(GeminiVoice.lastError) } else GeminiVoice.play(pcm)
                }.start()
            }
        }
        btn("▶ Maya शुरू करें") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) toast("पहले माइक की अनुमति दें")
            else startForegroundService(Intent(this, MayaService::class.java))
        }
        btn("■ रोकें (Kill switch)") { stopService(Intent(this, MayaService::class.java)) }
        col.addView(TextView(this).apply { text = "\n'माया, ...' बोलकर आदेश दें। संवेदनशील काम से पहले Maya पूछेगी।" })
        setContentView(ScrollView(this).apply { addView(col) })
    }
    private fun showErr(e: String) = android.app.AlertDialog.Builder(this)
        .setTitle("आवाज़ नहीं बनी").setMessage(e.ifBlank { "अज्ञात त्रुटि" }).setPositiveButton("ठीक", null).show()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
