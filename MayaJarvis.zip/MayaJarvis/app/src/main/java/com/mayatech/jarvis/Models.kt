package com.mayatech.jarvis

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini के मॉडल बदलते रहते हैं। 404/व्यस्त (503) पर दोबारा कोशिश और अगला मॉडल आज़माया जाता है। */
object Models {
    val LIST = listOf("gemini-3.8-flash", "gemini-flash-latest", "gemini-2.5-flash")
    @Volatile var good: String? = null
    fun order(): List<String> = listOfNotNull(good) + LIST.filter { it != good }

    fun call(key: String, body: JSONObject): JSONObject {
        var last = JSONObject()
        for (m in order()) {
            for (attempt in 0..2) {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val s = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
                last = try { JSONObject(s) } catch (e: Exception) { JSONObject().put("error", JSONObject().put("code", code).put("message", s.take(150))) }
                if (code == 503 && attempt < 2) { Thread.sleep(1500L * (attempt + 1)); continue }
                if (code == 404 || code == 503) break
                good = m; return last
            }
        }
        return last
    }
}
