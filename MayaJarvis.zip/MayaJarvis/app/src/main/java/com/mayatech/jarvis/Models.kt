package com.mayatech.jarvis

/** Gemini के मॉडल बदलते रहते हैं। नया पहले आज़माया जाता है, 404 आए तो अगला। */
object Models {
    val LIST = listOf("gemini-3.8-flash", "gemini-2.5-flash")
    @Volatile var good: String? = null
    fun order(): List<String> = listOfNotNull(good) + LIST.filter { it != good }
}
