package com.mayatech.jarvis

import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.io.File

/** Gemini जो टूल मांगे, उन्हें यहाँ चलाया जाता है */
object Tools {
    // इन ऐप्स पर ऑटो-कंट्रोल बंद (सुरक्षा)
    private val blocked = listOf("bank", "paytm", "phonepe", "gpay", "pay", "upi", "wallet", "sbi", "hdfc", "icici")

    fun run(name: String, a: JSONObject): String {
        val svc = MayaAccessibilityService.instance
        val ctx = MayaService.ctx ?: return "सेवा चालू नहीं है"
        fun needA11y(f: (MayaAccessibilityService) -> String) = svc?.let(f) ?: "Accessibility चालू नहीं है"
        return try { when (name) {
            "open_app" -> {
                val q = a.optString("name").lowercase()
                if (blocked.any { q.contains(it) }) return "सुरक्षा कारण से यह ऐप मैं नहीं खोल सकती।"
                val pm = ctx.packageManager
                val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val hit = l.firstOrNull { pm.getApplicationLabel(it.activityInfo.applicationInfo).toString().lowercase().contains(q) }
                    ?: return "ऐप नहीं मिला"
                val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                (svc ?: ctx).startActivity(i); "खुल गया"
            }
            "open_url" -> { (svc ?: ctx).startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "खुल गया" }
            "read_screen" -> needA11y { it.readScreen() }
            "tap_text" -> needA11y { if (it.tapText(a.getString("text"))) "टैप हो गया" else "वह टेक्स्ट नहीं दिखा" }
            "scroll" -> needA11y { if (it.scroll(a.optString("direction") != "up")) "स्क्रॉल हुआ" else "स्क्रॉल नहीं हो सका" }
            "type_text" -> needA11y { if (it.typeText(a.getString("text"))) "लिख दिया" else "इनपुट बॉक्स नहीं मिला" }
            "go_back" -> needA11y { it.back(); "ठीक" }
            "go_home" -> needA11y { it.home(); "ठीक" }
            "create_website" -> {
                val dir = ctx.getExternalFilesDir("websites")!!.apply { mkdirs() }
                val f = File(dir, a.optString("filename", "site.html").replace("/", "_")); f.writeText(a.getString("html"))
                "सेव हुई: ${f.absolutePath}"
            }
            else -> "अज्ञात टूल"
        } } catch (e: Exception) { "त्रुटि: ${e.message}" }
    }
}
