package com.mayatech.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Gemini जो टूल मांगे, उन्हें यहाँ चलाया जाता है */
object Tools {
    // इन ऐप्स पर ऑटो-कंट्रोल बंद (सुरक्षा)
    private val blocked = listOf("bank", "paytm", "phonepe", "gpay", "pay", "upi", "wallet", "sbi", "hdfc", "icici", "paisa")

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (MayaAccessibilityService.instance ?: ctx).startActivity(i)
    }

    private fun number(ctx: Context, target: String): String? {
        if (Regex("^[+0-9 \\-]{5,}$").matches(target.trim())) return target.trim()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$target%"), null)
        c?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun gemini(ctx: Context, parts: JSONArray, grounded: Boolean): String {
        val key = ctx.getSharedPreferences("maya", Context.MODE_PRIVATE).getString("key", "") ?: ""
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        if (grounded) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val s = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        val j = JSONObject(s)
        j.optJSONObject("error")?.let { return "त्रुटि: " + it.optString("message").take(150) }
        val p = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        return (0 until p.length()).joinToString("") { p.getJSONObject(it).optString("text") }.ifBlank { "कोई जवाब नहीं मिला" }
    }

    fun run(name: String, a: JSONObject): String {
        val svc = MayaAccessibilityService.instance
        val ctx = MayaService.ctx ?: return "सेवा चालू नहीं है"
        fun needA11y(f: (MayaAccessibilityService) -> String): String {
            val s = svc ?: return "Accessibility चालू नहीं है"
            val pkg = s.foregroundPackage()
            if (blocked.any { pkg.contains(it) }) return "सुरक्षा कारण से इस ऐप की स्क्रीन मैं नहीं छूती या देखती।"
            return f(s)
        }
        return try { when (name) {
            "open_app" -> {
                val q = a.optString("name").lowercase()
                if (blocked.any { q.contains(it) }) return "सुरक्षा कारण से यह ऐप मैं नहीं खोल सकती।"
                val pm = ctx.packageManager
                val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val hit = l.firstOrNull { pm.getApplicationLabel(it.activityInfo.applicationInfo).toString().lowercase().contains(q) }
                    ?: return "ऐप नहीं मिला"
                launch(ctx, pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!); "खुल गया"
            }
            "open_url" -> { launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url")))); "खुल गया" }
            "read_screen" -> needA11y { it.readScreen() }
            "tap_text" -> needA11y { if (it.tapText(a.getString("text"))) "टैप हो गया" else "वह टेक्स्ट नहीं दिखा" }
            "scroll" -> needA11y { if (it.scroll(a.optString("direction") != "up")) "स्क्रॉल हुआ" else "स्क्रॉल नहीं हो सका" }
            "type_text" -> needA11y { if (it.typeText(a.getString("text"))) "लिख दिया" else "इनपुट बॉक्स नहीं मिला" }
            "go_back" -> needA11y { it.back(); "ठीक" }
            "go_home" -> needA11y { it.home(); "ठीक" }
            "create_website" -> {
                val dir = ctx.getExternalFilesDir("websites")!!.apply { mkdirs() }
                val f = File(dir, a.optString("filename", "site.html").replace("/", "_")); f.writeText(a.getString("html"))
                "सेव हुई: ${f.absolutePath}"
            }
            "call_phone" -> {
                val t = a.optString("target")
                if (a.optString("confirmed") != "yes") return "पहले यूज़र से पूछो: क्या मैं $t को कॉल करूँ? 'हाँ' मिलने पर confirmed=yes के साथ दोबारा चलाओ।"
                if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return "कॉल की अनुमति नहीं मिली। ऐप में अनुमतियाँ दें।"
                val n = number(ctx, t) ?: return "$t का नंबर नहीं मिला (संपर्क की अनुमति जाँचें)"
                launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n)))); "कॉल लगाई जा रही है"
            }
            "send_sms" -> {
                val t = a.optString("target"); val msg = a.optString("message")
                if (a.optString("confirmed") != "yes") return "पहले यूज़र को पढ़कर सुनाओ: '$t को लिखा जाएगा: $msg'। 'हाँ' मिलने पर confirmed=yes के साथ दोबारा चलाओ।"
                if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return "SMS की अनुमति नहीं मिली। ऐप में अनुमतियाँ दें।"
                val n = number(ctx, t) ?: return "$t का नंबर नहीं मिला"
                val sm = ctx.getSystemService(SmsManager::class.java)
                sm.sendMultipartTextMessage(n, null, sm.divideMessage(msg), null, null); "SMS भेज दिया"
            }
            "torch" -> {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    ?: return "इस फ़ोन में टॉर्च नहीं मिली"
                val on = a.optString("state") != "off"
                cm.setTorchMode(id, on); if (on) "टॉर्च चालू" else "टॉर्च बंद"
            }
            "open_camera" -> { launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); "कैमरा खुल गया" }
            "set_alarm" -> {
                val h = a.optString("hour").toInt(); val m = a.optString("minute").toInt()
                launch(ctx, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Maya")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "अलार्म $h:%02d के लिए लगा दिया".format(m)
            }
            "set_timer" -> {
                val s = a.optString("seconds").toInt()
                launch(ctx, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Maya")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "$s सेकंड का टाइमर लगा दिया"
            }
            "web_search" -> gemini(ctx, JSONArray().put(JSONObject().put("text",
                "इंटरनेट पर खोजकर हिंदी में 3-4 छोटे वाक्यों में सटीक, ताज़ा जवाब दो: " + a.optString("query"))), true)
            else -> "अज्ञात टूल"
        } } catch (e: Exception) { "त्रुटि: ${e.message}" }
    }
}
