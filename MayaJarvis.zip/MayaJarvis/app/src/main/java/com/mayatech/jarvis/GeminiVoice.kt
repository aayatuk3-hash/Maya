package com.mayatech.jarvis

import android.media.*
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini की प्राकृतिक आवाज़ (TTS)। असफल होने पर null लौटाता है, तब फ़ोन की आवाज़ चलती है। */
object GeminiVoice {
    val FEMALE = listOf("Kore", "Aoede", "Leda", "Autonoe", "Callirrhoe", "Despina", "Erinome", "Laomedeia", "Achernar", "Gacrux", "Pulcherrima")
    const val MODEL = "gemini-2.5-flash-preview-tts"

    fun synth(key: String, voice: String, text: String): ByteArray? = try {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Say in a warm, friendly tone: $text")))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode >= 400) null else {
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val b64 = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
            Base64.decode(b64, Base64.DEFAULT)
        }
    } catch (e: Exception) { null }

    /** 24kHz, 16-bit, mono PCM चलाता है और खत्म होने तक रुकता है */
    fun play(pcm: ByteArray) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
        t.write(pcm, 0, pcm.size); t.play()
        Thread.sleep(pcm.size / 2 * 1000L / 24000 + 300)
        t.release()
    }
}
